//
//  TimeOutApplication.m
//  TouchOutLoginDemo
//
//  Created by wangting on 15/12/10.
//  Copyright © 2015年 Greenland. All rights reserved.
//http://blog.csdn.net/kmyhy/article/details/9716333

#import "TimeOutApplication.h"

@implementation TimeOutApplication

-(void)sendEvent:(UIEvent *)event {
    
    [super sendEvent:event];
    
    if (!myidleTimer) {
        
        [self resetIdleTimer];
        
    }
    
    NSSet *allTouches = [event allTouches];
    
    if ([allTouches count] > 0) {
        
        UITouchPhase phase= ((UITouch *)
                             
                             [allTouches anyObject]).phase;
        
        if (phase ==UITouchPhaseBegan) {
            
            [self resetIdleTimer];
            
        }
    }
}

//重置时钟

-(void)resetIdleTimer {
    
    if (myidleTimer) {
        
        [myidleTimer invalidate];
        
    }
    
    //将超时时间由分钟转换成秒数
    
    int timeout =
    
    kApplicationTimeoutInMinutes* 60;
    
    myidleTimer = [NSTimer scheduledTimerWithTimeInterval:timeout target:self selector:@selector(idleTimerExceeded)userInfo:nil repeats:NO];
    
}

//当达到超时时间，张贴 kApplicationTimeoutInMinutes通知

-(void)idleTimerExceeded {
    [[NSNotificationCenter defaultCenter]postNotificationName:kApplicationDidTimeoutNotification object:nil];
}



@end
