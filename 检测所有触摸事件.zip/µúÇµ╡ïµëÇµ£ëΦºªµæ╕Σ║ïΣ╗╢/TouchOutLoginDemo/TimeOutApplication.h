//
//  TimeOutApplication.h
//  TouchOutLoginDemo
//
//  Created by wangting on 15/12/10.
//  Copyright © 2015年 Greenland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#define kApplicationTimeoutInMinutes 1 

#define kApplicationDidTimeoutNotification @"AppTimeOut"


@interface TimeOutApplication : UIApplication
{
    NSTimer     *myidleTimer;
}

-(void)resetIdleTimer;

@end
