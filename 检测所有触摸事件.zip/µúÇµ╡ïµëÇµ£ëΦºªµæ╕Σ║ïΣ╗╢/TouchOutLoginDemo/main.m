//
//  main.m
//  TouchOutLoginDemo
//
//  Created by wangting on 15/12/10.
//  Copyright © 2015年 Greenland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "TimeOutApplication.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass([TimeOutApplication class]), NSStringFromClass([AppDelegate class]));
        }
}
