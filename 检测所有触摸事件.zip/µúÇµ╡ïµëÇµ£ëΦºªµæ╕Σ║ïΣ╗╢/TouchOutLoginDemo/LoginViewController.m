//
//  LoginViewController.m
//  TouchOutLoginDemo
//
//  Created by wangting on 15/12/10.
//  Copyright © 2015年 Greenland. All rights reserved.
//

#import "LoginViewController.h"
#import "TimeOutApplication.h"

@interface LoginViewController ()
- (IBAction)login:(id)sender;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)login:(id)sender {
    
    [(TimeOutApplication *)[UIApplication sharedApplication] resetIdleTimer];
    [self.parentViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
